"""Read-only exact-C stop/liquidity provenance; two authorized native paths only.

All wrapped production methods execute once. Observations are copied into this
external script's buffers, never fed back into strategy, risk, or execution.
Close snapshots slice every observed price/volume series at the current close.
Later open snapshots are separate realized evidence, not close-known inputs.
"""
from __future__ import annotations

import argparse
import contextlib
import copy
import functools
import hashlib
import io
import json
import lzma
import math
import pickle
import subprocess
import sys
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict, is_dataclass
from pathlib import Path
from unittest.mock import patch

EXACT_REVISION = "af2389b883949a55ded6e8a428f3e8e2353e3c27"
EXACT_SOURCE = "1b1707feb8f662edaeb24526ebd997bdbde293089324ec1008ba18d1e2003773"
EXACT_DATA = "aeeb96a94e84830033e8ad11180293fc982bb08e99322054d2c27dbb3f4b5975"
BASELINE_WEALTH = {"prefix-01": 4.928538056569,
                   "random-20260817-03-027": 7.638286270395501}


def safe(value):
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if is_dataclass(value):
        return safe(asdict(value))
    if isinstance(value, dict):
        return {str(k): safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set, frozenset)):
        return [safe(v) for v in value]
    if hasattr(value, "item"):
        return safe(value.item())
    return str(value)


def scalar_state(obj):
    return {k: safe(v) for k, v in vars(obj).items()
            if v is None or isinstance(v, (str, bool, int, float))
            or k == "policy"}


def queue_rows(queue):
    return [{"signal": safe(vars(signal)),
             "owner_name": getattr(owner, "name", None),
             "owner_present": owner is not None} for signal, owner in queue]


def position_rows(sleeve):
    return {symbol: {name: safe(vars(pos)) for name, pos in books.items()}
            for symbol, books in sleeve.positions.items()}


@contextlib.contextmanager
def observe(rows):
    import pandas as pd
    from quantfusion.domain.rules import floor_to_lot
    from quantfusion.engine.causal import _CausalBacktestEngine
    from quantfusion.engine.ensemble import _EnsembleSleeveBacktestEngine
    from quantfusion.engine import ensemble_allocation, replay_loop
    from quantfusion.risk import account_budget
    from quantfusion.strategy.trend import (
        ATRChannelStrategy, DualMAStrategy, TurtleBreakoutStrategy,
    )

    native_updates = {}
    active_apply = []

    def wrap_native(method):
        @functools.wraps(method)
        def wrapped(owner, ctx):
            before = safe(vars(owner.position)) if owner.position is not None else None
            result = method(owner, ctx)
            update = {
                "date": str(ctx.date), "symbol": ctx.symbol, "strategy": owner.name,
                "before": before,
                "after": safe(vars(owner.position)) if owner.position is not None else None,
                "emitted_signal": safe(vars(result)) if result is not None else None,
                "current_indicators": {name: safe(float(series.iloc[ctx.i]))
                                       for name, series in ctx.indicators.items()},
                "native_cfg": safe(owner.cfg),
            }
            native_updates[id(owner)] = update
            return result
        return wrapped

    original_plan = account_budget.plan_account_risk_budget

    @functools.wraps(original_plan)
    def plan_once(*args, **kwargs):
        result = original_plan(*args, **kwargs)
        if active_apply:
            active_apply[-1]["planner_inputs"] = {
                "books": safe(args[3]), "buys": safe(args[4]),
                "options": safe(kwargs), "effective_cfg": safe(args[2]),
            }
            active_apply[-1]["planner_receipt"] = safe(copy.deepcopy(result[0]))
            active_apply[-1]["planned_actions"] = safe(copy.deepcopy(result[1]))
        return result

    original_apply = account_budget.apply_account_risk_budget

    @functools.wraps(original_apply)
    def apply_once(states, date, assets, peak, cfg, score, events, **kwargs):
        date_str = date.strftime("%Y-%m-%d")
        snapshot = {"phase": "close_budget", "date": date_str,
                    "assets": float(assets), "lifetime_peak": float(peak),
                    "cfg": safe(cfg), "apply_options": safe(kwargs), "states": [],
                    "events_before_today": safe([e for e in events if e.get("date") == date_str])}
        for state_index, state in enumerate(states):
            sleeve = state.sleeve
            state_row = {"state_index": state_index, "sleeve": sleeve.sleeve_name,
                         "cash": float(sleeve.cash), "sleeve_state": scalar_state(sleeve),
                         "risk_state": scalar_state(sleeve.risk),
                         "policy": safe(getattr(sleeve, "policy", None)),
                         "pending_before": queue_rows(state.pending), "books": []}
            for symbol, books in sorted(sleeve.positions.items()):
                history = state.data_map[symbol].loc[
                    state.data_map[symbol].index <= date].copy(deep=False)
                close = float(history["close"].iloc[-1])
                volumes = pd.to_numeric(history["volume"], errors="coerce").dropna()
                volumes = volumes.loc[volumes.gt(0)]
                policy = getattr(sleeve, "policy", None)
                lookback = int(policy.adv_lookback) if policy is not None else 20
                ratio = float(policy.max_order_adv_ratio) if policy is not None else None
                adv_window = volumes.tail(lookback)
                adv = float(adv_window.mean()) if not adv_window.empty else 0.
                prospective_capacity = floor_to_lot(adv * ratio) if ratio is not None else None
                total_symbol_shares = sum(int(pos.shares) for pos in books.values())
                owners = list(sleeve.strategy_instances.get(symbol, [])) + list(
                    sleeve.external_strategy_instances.get(symbol, []))
                for name, position in sorted(books.items()):
                    if not position.shares:
                        continue
                    matching_owners = [owner for owner in owners if owner.name == name]
                    provenance = [{"same_book_object": owner.position is position,
                                   "cfg": safe(owner.cfg),
                                   "last_native_update": copy.deepcopy(native_updates.get(id(owner)))}
                                  for owner in matching_owners]
                    owner_cfg = matching_owners[0].cfg if matching_owners else sleeve.cfg
                    atr_period = int(owner_cfg["atr_period"])
                    # u is a full completed trigger session; u+1's open is
                    # observed only when its row is already in `history`.
                    bridges = []
                    for j in range(max(2, len(history) - atr_period), len(history)):
                        start_close = float(history["close"].iloc[j-2])
                        end_open = float(history["open"].iloc[j])
                        bridges.append({"start_close_date": str(history.index[j-2].date()),
                                        "trigger_date": str(history.index[j-1].date()),
                                        "exit_open_date": str(history.index[j].date()),
                                        "start_close": start_close, "exit_open": end_open,
                                        "loss": max(0., 1. - end_open/start_close)})
                    empirical = max((item["loss"] for item in bridges), default=0.)
                    tail = max(float(cfg["daily_loss_limit"]), empirical)
                    stop = float(position.stop_loss)
                    stop_distance = max(close-stop, 0.)
                    current_buy_shares = sum(t.shares for t in sleeve.trades
                                             if t.date == date_str and t.symbol == symbol
                                             and t.direction == "buy"
                                             and t.strategy_name.split(":")[-1] == name)
                    state_row["books"].append({
                        "state_index": state_index, "symbol": symbol, "strategy": name,
                        "position": safe(vars(position)), "close": close,
                        "last_observed_market_date": str(history.index[-1].date()),
                        "owner_provenance": provenance,
                        "atr_period": atr_period, "empirical_bridge_samples": bridges,
                        "empirical_bridge_loss": empirical, "floored_exit_lag_loss": tail,
                        "native_stop_distance": stop_distance,
                        "native_stop_breached": close <= stop,
                        "stop_plus_lag_loss_per_share": stop_distance + close*tail,
                        "stop_plus_lag_reserve": position.shares*(stop_distance+close*tail),
                        "current_close_gross": position.shares*close,
                        "today_actual_buy_shares": current_buy_shares,
                        "settled_before_current_close_shares": max(0, position.shares-current_buy_shares),
                        "next_session_T1_eligible_shares_if_market_tradable": position.shares,
                        "prospective_next_open_adv": adv,
                        "prospective_next_open_adv_capacity_per_sleeve_symbol_side": prospective_capacity,
                        "adv_lookback": lookback, "adv_ratio": ratio,
                        "adv_observation_dates": [str(stamp.date()) for stamp in adv_window.index],
                        "adv_observed_volumes": [float(value) for value in adv_window],
                        "total_live_sleeve_symbol_shares": total_symbol_shares,
                        "full_symbol_liquidation_sessions_at_current_adv": (
                            math.ceil(total_symbol_shares/prospective_capacity)
                            if prospective_capacity else None),
                        "next_open_price_and_tradability": "unknown_at_close",
                    })
            snapshot["states"].append(state_row)
        active_apply.append(snapshot)
        original_apply(states, date, assets, peak, cfg, score, events, **kwargs)
        active_apply.pop()
        snapshot["states_pending_after"] = [queue_rows(state.pending) for state in states]
        snapshot["emitted_budget_event"] = safe(copy.deepcopy(events[-1]))
        rows.append(snapshot)

    original_prepare = _CausalBacktestEngine._prepare_open_signal

    @functools.wraps(original_prepare)
    def prepare_once(sleeve, signal, data_map, date, date_to_pos):
        result = original_prepare(sleeve, signal, data_map, date, date_to_pos)
        if signal.direction == "sell":
            rows.append({"phase": "realized_open_preparation", "date": str(date.date()),
                         "sleeve": sleeve.sleeve_name, "signal": safe(vars(signal)),
                         "prepared_signal": safe(vars(result[0])) if result[0] is not None else None,
                         "keep_pending": result[1],
                         "not_known_at_prior_close": True})
        return result

    original_sell = _EnsembleSleeveBacktestEngine._execute_sell

    @functools.wraps(original_sell)
    def sell_once(sleeve, signal, strategy, date_str):
        position = sleeve.positions.get(signal.symbol, {}).get(signal.strategy_name)
        before = safe(vars(position)) if position is not None else None
        context_date = sleeve._execution_date
        data_map = sleeve._execution_data_map
        adv = sleeve._adv_capacity(signal.symbol, "sell", data_map, context_date) if data_map is not None else None
        cash_before = float(sleeve.cash)
        result = original_sell(sleeve, signal, strategy, date_str)
        position = sleeve.positions.get(signal.symbol, {}).get(signal.strategy_name)
        rows.append({"phase": "realized_sell", "date": date_str, "sleeve": sleeve.sleeve_name,
                     "signal": safe(vars(signal)), "book_before": before,
                     "book_after": safe(vars(position)) if position is not None else None,
                     "prior_adv_capacity_and_mean_before_sell": safe(adv),
                     "cash_before": cash_before, "cash_after": float(sleeve.cash),
                     "actual_filled_shares": result, "not_known_at_prior_close": True})
        return result

    with contextlib.ExitStack() as stack:
        for cls in (ATRChannelStrategy, DualMAStrategy, TurtleBreakoutStrategy):
            stack.enter_context(patch.object(cls, "on_bar", wrap_native(cls.on_bar)))
        stack.enter_context(patch.object(account_budget, "plan_account_risk_budget", plan_once))
        for module in (account_budget, ensemble_allocation, replay_loop):
            stack.enter_context(patch.object(module, "apply_account_risk_budget", apply_once))
        stack.enter_context(patch.object(_CausalBacktestEngine, "_prepare_open_signal", prepare_once))
        stack.enter_context(patch.object(_EnsembleSleeveBacktestEngine, "_execute_sell", sell_once))
        yield


def run_one(sid, root, out):
    start = time.monotonic()
    sys.path.insert(0, str(root))
    from quantfusion.engine.replay import ProductionReplayEngine
    from quantfusion.application import stress_scenarios as scenarios
    from quantfusion.config.paths import MARKET_DATA_DIR, REGIME_DATA_DIR
    from quantfusion.config.universe import SYMBOL_NAMES
    plan = {row["scenario_id"]: row for row in scenarios._multi_seed_scenarios(
        random_samples=50, permutation_samples=50, seeds=scenarios.DEFAULT_SEEDS)}
    rows = []
    with observe(rows), contextlib.redirect_stdout(io.StringIO()):
        result = ProductionReplayEngine(2_000_000).run(
            {code: SYMBOL_NAMES[code] for code in plan[sid]["symbols"]},
            "2025-04-01", "2026-07-20", data_dir=str(MARKET_DATA_DIR),
            regime_data_dir=str(REGIME_DATA_DIR), indicator_state="warm")
    raw = pickle.dumps(result, protocol=pickle.HIGHEST_PROTOCOL)
    trace = "\n".join(json.dumps(safe(row), sort_keys=True, allow_nan=False) for row in rows)+"\n"
    (out/(sid+".pkl.xz")).write_bytes(lzma.compress(raw))
    (out/(sid+"-stop-liquidity.jsonl.xz")).write_bytes(lzma.compress(trace.encode()))
    wealth = 1. + result["total_return"]
    summary = {"scenario_id": sid, "symbols": plan[sid]["symbols"],
               "wealth": wealth, "baseline_wealth": BASELINE_WEALTH[sid],
               "baseline_delta": wealth-BASELINE_WEALTH[sid],
               "baseline_matches": abs(wealth-BASELINE_WEALTH[sid]) <= 1e-10,
               "max_drawdown": result["max_drawdown"],
               "date_symbol_side_count": result["date_symbol_side_count"],
               "total_trades": result["total_trades"],
               "trace_rows": len(rows), "raw_pickle_sha256": hashlib.sha256(raw).hexdigest(),
               "trace_jsonl_sha256": hashlib.sha256(trace.encode()).hexdigest(),
               "runtime_seconds": time.monotonic()-start}
    (out/(sid+".json")).write_text(json.dumps(summary, indent=2)+"\n")
    if not summary["baseline_matches"]:
        raise AssertionError(f"Observer did not reproduce exact C baseline: {summary}")
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    args.root = args.root.resolve()
    sys.path.insert(0, str(args.root))
    from quantfusion.application import stress_artifacts as artifacts
    from quantfusion.config.paths import MARKET_DATA_DIR, REGIME_DATA_DIR
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=args.root, text=True).strip()
    status = subprocess.check_output(["git", "status", "--porcelain"], cwd=args.root, text=True)
    source = artifacts._tree_fingerprint(artifacts._source_files())
    data = artifacts._tree_fingerprint(artifacts._data_files(MARKET_DATA_DIR, REGIME_DATA_DIR))
    if (revision, source, data, status) != (EXACT_REVISION, EXACT_SOURCE, EXACT_DATA, ""):
        raise ValueError(f"Exact C source/data/clean-state mismatch: {revision}, {source}, {data}, {status}")
    args.out.mkdir(parents=True, exist_ok=False)
    script = Path(__file__).read_bytes()
    (args.out/"risk-stop-observer.py").write_bytes(script)
    identity = {"source_revision": revision, "source_fingerprint": source,
                "data_fingerprint": data, "observer_sha256": hashlib.sha256(script).hexdigest(),
                "scenario_ids": list(BASELINE_WEALTH), "cfg_overrides": {}, "python": sys.version,
                "canonical": False, "allow_publication": False, "read_only_observer": True,
                "purpose": "Missing native-stop and liquidity provenance only; no policy experiment"}
    (args.out/"identity.json").write_text(json.dumps(identity, indent=2)+"\n")
    summaries = []
    with ProcessPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(run_one, sid, args.root, args.out) for sid in BASELINE_WEALTH]
        for future in as_completed(futures):
            summary = future.result()
            summaries.append(summary)
            print(json.dumps(summary), flush=True)
    (args.out/"results.json").write_text(json.dumps(summaries, indent=2)+"\n")
    manifest = {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                for path in sorted(args.out.iterdir()) if path.is_file()}
    (args.out/"SHA256SUMS.json").write_text(json.dumps(manifest, indent=2)+"\n")
    final_status = subprocess.check_output(["git", "status", "--porcelain"], cwd=args.root, text=True)
    if final_status:
        raise AssertionError(f"Source unexpectedly changed: {final_status}")
    print("COMPLETE 2; source clean; exact C baselines matched", flush=True)


if __name__ == "__main__":
    main()
