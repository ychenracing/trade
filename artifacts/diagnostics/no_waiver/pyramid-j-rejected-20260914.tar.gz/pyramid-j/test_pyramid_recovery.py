"""Pyramid additions require observed trend recovery; exits remain immediate."""
import pandas as pd

from quantfusion.domain.models import BarContext, Position
from quantfusion.strategy.trend import TurtleBreakoutStrategy


def signal(close):
    strategy = TurtleBreakoutStrategy({"reversal_turtle_enabled": False})
    strategy.position = Position(
        "300308", "turtle_breakout", 1000, 100., "2025-01-02",
        highest_since_entry=122., highest_close_since_entry=120.,
        last_add_price=100.,
    )
    frame = pd.DataFrame({"close": [close] * 30, "high": [max(close, 119.)] * 30})
    indicators = {key: pd.Series([value] * 30) for key, value in {
        "atr": 2., "adx": 30., "donchian_upper": 115., "donchian_lower": 90.,
    }.items()}
    return strategy.on_bar(BarContext(29, frame, 100000., indicators, "300308", "2025-02-14"))


def test_old_buy_anchor_does_not_authorize_pyramid_below_observed_peak():
    assert signal(118.) is None


def test_recovered_close_allows_funded_pyramid_signal():
    result = signal(121.)
    assert result is not None and result.direction == "buy"


def test_equal_peak_allows_recovery_without_future_high():
    result = signal(120.)
    assert result is not None and result.direction == "buy"


def test_trailing_safety_exit_precedes_pyramid_recovery():
    result = signal(116.)
    assert result is not None and result.direction == "sell"
