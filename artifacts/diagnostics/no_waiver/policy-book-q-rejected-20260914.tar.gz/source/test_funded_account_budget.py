"""Unfunded intents must not consume a real account's loss allowance."""
from types import SimpleNamespace

from quantfusion.domain.models import Signal
from tests.c6_non_economic.test_account_risk_budget import fixture, apply


def test_zero_cash_sleeve_cannot_dilute_another_sleeves_budget():
    engine, funded, dates = fixture(shares=2000, cash=70000.)
    _, empty, _ = fixture(shares=0, cash=0.)
    buy = Signal('300308', 'turtle_breakout', 'buy', target_shares=10000,
                 price=10., signal_date='2026-01-05')
    strategy = SimpleNamespace(name='turtle_breakout', cfg=funded.sleeve.cfg)
    funded.pending = [(buy, strategy)]
    apply(engine, [funded, empty], dates)
    expected = [s.target_shares for s, _ in funded.pending if s.direction == 'buy']
    funded.pending = [(buy, strategy)]
    empty.pending = [(buy, strategy)]
    apply(engine, [funded, empty], dates)
    assert [s.target_shares for s, _ in funded.pending if s.direction == 'buy'] == expected
    assert not any(s.direction == 'buy' for s, _ in empty.pending)
